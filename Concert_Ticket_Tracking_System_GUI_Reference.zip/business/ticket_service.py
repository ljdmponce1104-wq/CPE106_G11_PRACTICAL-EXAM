import re
from data.ticket_repository import TicketRepository

class TicketService:
    """Business-logic layer: validation and queue rules."""

    EVENTS = {
        "2026 ByeonWooSeok Asia Fanmeeting Tour — The Secret Library in Manila": {
            "date": "October 10, 2026 • 6:00 PM",
            "venue": "SM Mall of Asia Arena",
            "ticket_types": ("SVIP 1", "SVIP 2", "VIP A", "VIP B", "BOX PREMIUM", "BOX REGULAR"),
        },
        "2026 LE SSERAFIM TOUR — PUREFLOW IN MANILA": {
            "date": "October 16, 2026 • 5:00 PM",
            "venue": "SM Mall of Asia Arena",
            "ticket_types": ("VIP", "Standing", "Lower Box", "Upper Box"),
        },
        "FINALE — 40th Anniversary Concert": {
            "date": "October 18, 2026 • 8:00 PM",
            "venue": "SM Mall of Asia Arena",
            "ticket_types": ("VIP", "Lower Box", "Upper Box", "General Admission"),
        },
    }

    def __init__(self):
        self.repo = TicketRepository()

    def event_names(self):
        return tuple(self.EVENTS.keys())

    def get_event_info(self, event_name):
        return self.EVENTS.get(event_name)

    def validate_ticket(self, customer_name, contact_number, event_name,
                        ticket_type, quantity):
        errors = []

        if not customer_name.strip():
            errors.append("Customer name is required.")
        elif len(customer_name.strip()) < 2:
            errors.append("Customer name must contain at least 2 characters.")

        contact = contact_number.strip()
        if not contact:
            errors.append("Contact number is required.")
        elif not re.fullmatch(r"[0-9+\-\s()]{7,20}", contact):
            errors.append("Contact number contains invalid characters.")

        event_info = self.EVENTS.get(event_name)
        if event_info is None:
            errors.append("Please select a valid event.")
        elif ticket_type not in event_info["ticket_types"]:
            errors.append("Please select a ticket type valid for the selected event.")

        try:
            qty = int(quantity)
            if qty < 1 or qty > 10:
                errors.append("Quantity must be from 1 to 10.")
        except (TypeError, ValueError):
            errors.append("Quantity must be a whole number.")

        return errors

    def add_ticket(self, customer_name, contact_number, event_name,
                   ticket_type, quantity):
        errors = self.validate_ticket(
            customer_name, contact_number, event_name, ticket_type, quantity
        )
        if errors:
            return False, errors, None

        event_date = self.EVENTS[event_name]["date"]
        queue_number = self.repo.add(
            customer_name.strip(),
            contact_number.strip(),
            event_name,
            event_date,
            ticket_type,
            int(quantity)
        )
        return True, [], queue_number

    def process_next(self):
        return self.repo.process_next()

    def search(self, keyword="", status="All"):
        return self.repo.search(keyword, status)

    def waiting_count(self):
        return self.repo.get_waiting_count()
