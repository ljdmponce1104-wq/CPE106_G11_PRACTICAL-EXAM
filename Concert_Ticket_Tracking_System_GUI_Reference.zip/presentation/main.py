import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import tkinter as tk
from tkinter import ttk, messagebox
from data.database import initialize_database
from business.ticket_service import TicketService


NAVY = "#0B2F68"
NAVY_DARK = "#071F4A"
TEAL = "#12B8A3"
TEAL_DARK = "#0A9D8C"
WHITE = "#FFFFFF"
LIGHT = "#F4F7FB"
TEXT = "#12345B"
MUTED = "#6B7C93"
BORDER = "#D9E1EC"
RED = "#C0392B"


class ConcertTicketApp(tk.Tk):
    def __init__(self):
        super().__init__()

        initialize_database()
        self.service = TicketService()

        self.title("Concert Ticket Tracking System")
        self.geometry("1240x820")
        self.minsize(1100, 720)
        self.configure(bg=LIGHT)

        self.name_var = tk.StringVar()
        self.contact_var = tk.StringVar()
        self.event_var = tk.StringVar()
        self.event_date_var = tk.StringVar(value="Select an event")
        self.venue_var = tk.StringVar(value="Select an event")
        self.type_var = tk.StringVar()
        self.quantity_var = tk.StringVar(value="1")

        self.search_var = tk.StringVar()
        self.status_var = tk.StringVar(value="All")
        self.queue_status_var = tk.StringVar()

        self._configure_styles()
        self._build_ui()
        self._select_first_event()
        self.refresh_table()

    def _configure_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")

        style.configure(
            "App.TFrame",
            background=LIGHT
        )
        style.configure(
            "Card.TLabelframe",
            background=WHITE,
            bordercolor=BORDER,
            relief="solid"
        )
        style.configure(
            "Card.TLabelframe.Label",
            background=WHITE,
            foreground=NAVY,
            font=("Arial", 11, "bold")
        )
        style.configure(
            "App.TLabel",
            background=WHITE,
            foreground=TEXT,
            font=("Arial", 10)
        )
        style.configure(
            "Muted.TLabel",
            background=WHITE,
            foreground=MUTED,
            font=("Arial", 9)
        )
        style.configure(
            "Title.TLabel",
            background=NAVY,
            foreground=WHITE,
            font=("Arial", 22, "bold")
        )
        style.configure(
            "Subtitle.TLabel",
            background=NAVY,
            foreground="#D9E7FF",
            font=("Arial", 9)
        )
        style.configure(
            "Hero.TLabel",
            background=NAVY,
            foreground=WHITE,
            font=("Arial", 12, "bold")
        )
        style.configure(
            "Teal.TButton",
            background=TEAL,
            foreground=WHITE,
            borderwidth=0,
            font=("Arial", 10, "bold"),
            padding=(16, 9)
        )
        style.map(
            "Teal.TButton",
            background=[("active", TEAL_DARK), ("disabled", "#A9CFC8")],
            foreground=[("disabled", "#F4F4F4")]
        )
        style.configure(
            "Navy.TButton",
            background=NAVY,
            foreground=WHITE,
            borderwidth=0,
            font=("Arial", 10, "bold"),
            padding=(14, 8)
        )
        style.map("Navy.TButton", background=[("active", NAVY_DARK)])
        style.configure(
            "Treeview",
            background=WHITE,
            fieldbackground=WHITE,
            foreground=TEXT,
            rowheight=31,
            bordercolor=BORDER,
            font=("Arial", 9)
        )
        style.configure(
            "Treeview.Heading",
            background=NAVY,
            foreground=WHITE,
            font=("Arial", 9, "bold"),
            padding=7
        )
        style.map("Treeview", background=[("selected", "#DDF5F1")])

    def _build_ui(self):
        # Top navigation/header
        header = tk.Frame(self, bg=WHITE, height=82)
        header.pack(fill="x")
        header.pack_propagate(False)

        logo = tk.Frame(header, bg=WHITE)
        logo.pack(side="left", padx=22)

        tk.Label(
            logo, text="TICKETS", bg=WHITE, fg=NAVY,
            font=("Arial", 18, "bold")
        ).pack(side="left")

        tk.Label(
            logo, text="QUEUE", bg=WHITE, fg=TEAL,
            font=("Arial", 18, "bold")
        ).pack(side="left", padx=(2, 0))

        tk.Label(
            logo, text="  |  GROUP 11", bg=WHITE, fg=MUTED,
            font=("Arial", 9, "bold")
        ).pack(side="left", padx=12)

        nav = tk.Frame(header, bg=WHITE)
        nav.pack(side="right", padx=22)

        tk.Label(
            nav, text="SOFTWARE DESIGN LABORATORY",
            bg=WHITE, fg=NAVY, font=("Arial", 10, "bold")
        ).pack(side="left", padx=15)

        # Hero section inspired by the reference site's navy banner
        hero = tk.Frame(self, bg=NAVY, height=165)
        hero.pack(fill="x")
        hero.pack_propagate(False)

        hero_left = tk.Frame(hero, bg=NAVY)
        hero_left.pack(side="left", fill="both", expand=True, padx=42, pady=24)

        ttk.Label(
            hero_left,
            text="CONCERT TICKET TRACKING SYSTEM",
            style="Title.TLabel"
        ).pack(anchor="w")

        ttk.Label(
            hero_left,
            text="A small-scale FIFO queue management system for concert ticket requests",
            style="Subtitle.TLabel"
        ).pack(anchor="w", pady=(6, 14))

        self.hero_queue = ttk.Label(
            hero_left,
            text="WAITING REQUESTS: 0",
            style="Hero.TLabel"
        )
        self.hero_queue.pack(anchor="w")

        tk.Label(
            hero, text="FIFO", bg=TEAL, fg=WHITE,
            font=("Arial", 22, "bold"), padx=22, pady=14
        ).pack(side="right", padx=42, pady=45)

        # Main scrollable-ish area using a fixed grid
        content = tk.Frame(self, bg=LIGHT)
        content.pack(fill="both", expand=True, padx=22, pady=18)

        content.columnconfigure(0, weight=1)
        content.columnconfigure(1, weight=1)
        content.rowconfigure(2, weight=1)

        # Event selection
        event_card = ttk.LabelFrame(
            content, text="  SELECT EVENT  ", style="Card.TLabelframe", padding=14
        )
        event_card.grid(row=0, column=0, sticky="nsew", padx=(0, 9), pady=(0, 12))

        ttk.Label(event_card, text="Concert/Event", style="App.TLabel").grid(
            row=0, column=0, sticky="w", pady=(0, 4)
        )

        self.event_combo = ttk.Combobox(
            event_card,
            textvariable=self.event_var,
            values=self.service.event_names(),
            state="readonly",
            width=54
        )
        self.event_combo.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        self.event_combo.bind("<<ComboboxSelected>>", self._event_changed)

        ttk.Label(
            event_card, textvariable=self.event_date_var, style="Muted.TLabel"
        ).grid(row=2, column=0, sticky="w")

        ttk.Label(
            event_card, textvariable=self.venue_var, style="Muted.TLabel"
        ).grid(row=3, column=0, sticky="w", pady=(3, 0))

        # Request form
        form = ttk.LabelFrame(
            content, text="  TICKET REQUEST  ", style="Card.TLabelframe", padding=14
        )
        form.grid(row=0, column=1, sticky="nsew", padx=(9, 0), pady=(0, 12))

        ttk.Label(form, text="Customer Name", style="App.TLabel").grid(
            row=0, column=0, sticky="w", padx=(0, 8), pady=4
        )
        ttk.Entry(form, textvariable=self.name_var, width=27).grid(
            row=0, column=1, sticky="ew", pady=4
        )

        ttk.Label(form, text="Contact Number", style="App.TLabel").grid(
            row=1, column=0, sticky="w", padx=(0, 8), pady=4
        )
        ttk.Entry(form, textvariable=self.contact_var, width=27).grid(
            row=1, column=1, sticky="ew", pady=4
        )

        ttk.Label(form, text="Ticket Type", style="App.TLabel").grid(
            row=2, column=0, sticky="w", padx=(0, 8), pady=4
        )
        self.type_combo = ttk.Combobox(
            form, textvariable=self.type_var, state="readonly", width=25
        )
        self.type_combo.grid(row=2, column=1, sticky="ew", pady=4)

        ttk.Label(form, text="Quantity (1–10)", style="App.TLabel").grid(
            row=3, column=0, sticky="w", padx=(0, 8), pady=4
        )
        ttk.Spinbox(
            form, from_=1, to=10, textvariable=self.quantity_var, width=25
        ).grid(row=3, column=1, sticky="ew", pady=4)

        ttk.Button(
            form, text="ADD TO FIFO QUEUE",
            style="Teal.TButton", command=self.add_ticket
        ).grid(row=4, column=1, sticky="e", pady=(9, 0))

        form.columnconfigure(1, weight=1)

        # Event cards
        cards = tk.Frame(content, bg=LIGHT)
        cards.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 12))
        cards.columnconfigure((0, 1, 2), weight=1)

        for i, event_name in enumerate(self.service.event_names()):
            info = self.service.get_event_info(event_name)
            card = tk.Frame(
                cards, bg=WHITE, highlightbackground=BORDER,
                highlightthickness=1
            )
            card.grid(row=0, column=i, sticky="nsew", padx=6)

            tk.Label(
                card, text="2026", bg=TEAL, fg=WHITE,
                font=("Arial", 9, "bold"), padx=10, pady=5
            ).pack(anchor="w", padx=12, pady=(12, 8))

            short = event_name.replace("2026 ", "").replace("—", "–")
            tk.Label(
                card, text=short, bg=WHITE, fg=NAVY,
                font=("Arial", 10, "bold"),
                wraplength=280, justify="left"
            ).pack(anchor="w", padx=12)

            tk.Label(
                card, text=info["date"], bg=WHITE, fg=MUTED,
                font=("Arial", 9)
            ).pack(anchor="w", padx=12, pady=(6, 2))

            tk.Label(
                card, text=info["venue"], bg=WHITE, fg=MUTED,
                font=("Arial", 9)
            ).pack(anchor="w", padx=12, pady=(0, 12))

            ttk.Button(
                card, text="SELECT",
                style="Navy.TButton",
                command=lambda n=event_name: self.select_event(n)
            ).pack(anchor="e", padx=12, pady=(0, 12))

        # Queue controls + table
        queue_card = ttk.LabelFrame(
            content, text="  QUEUE MANAGEMENT  ", style="Card.TLabelframe", padding=10
        )
        queue_card.grid(row=2, column=0, columnspan=2, sticky="nsew")

        controls = tk.Frame(queue_card, bg=WHITE)
        controls.pack(fill="x", pady=(0, 8))

        ttk.Button(
            controls, text="PROCESS NEXT (FIFO)",
            style="Teal.TButton", command=self.process_next
        ).pack(side="left", padx=(0, 8))

        ttk.Button(
            controls, text="REFRESH",
            style="Navy.TButton", command=self.refresh_table
        ).pack(side="left", padx=4)

        tk.Label(
            controls, text="Search", bg=WHITE, fg=NAVY,
            font=("Arial", 9, "bold")
        ).pack(side="left", padx=(28, 6))

        ttk.Entry(
            controls, textvariable=self.search_var, width=25
        ).pack(side="left", padx=4)

        status_combo = ttk.Combobox(
            controls, textvariable=self.status_var,
            values=("All", "Waiting", "Served"),
            state="readonly", width=9
        )
        status_combo.pack(side="left", padx=5)
        status_combo.bind("<<ComboboxSelected>>", lambda event: self.search_records())

        ttk.Button(
            controls, text="SEARCH",
            style="Navy.TButton", command=self.search_records
        ).pack(side="left", padx=4)

        ttk.Button(
            controls, text="CLEAR",
            command=self.clear_search
        ).pack(side="left", padx=4)

        tk.Label(
            controls, textvariable=self.queue_status_var,
            bg=WHITE, fg=TEAL_DARK, font=("Arial", 10, "bold")
        ).pack(side="right", padx=6)

        table_frame = tk.Frame(queue_card, bg=WHITE)
        table_frame.pack(fill="both", expand=True)

        columns = (
            "queue", "customer", "event", "date",
            "type", "qty", "status", "created"
        )
        self.tree = ttk.Treeview(
            table_frame, columns=columns, show="headings", selectmode="browse"
        )

        headings = {
            "queue": "QUEUE #", "customer": "CUSTOMER", "event": "EVENT",
            "date": "DATE", "type": "TICKET TYPE", "qty": "QTY",
            "status": "STATUS", "created": "CREATED"
        }
        widths = {
            "queue": 70, "customer": 150, "event": 230, "date": 160,
            "type": 110, "qty": 55, "status": 85, "created": 145
        }

        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="center")

        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=yscroll.set)

        self.tree.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")

        # Footer
        footer = tk.Frame(self, bg=NAVY_DARK, height=34)
        footer.pack(fill="x")
        footer.pack_propagate(False)

        tk.Label(
            footer,
            text="Mapúa University • Software Design Laboratory • Group 11 • FIFO Queue",
            bg=NAVY_DARK, fg="#D9E7FF", font=("Arial", 8)
        ).pack(side="left", padx=22, pady=9)

        tk.Label(
            footer,
            text="CPE106L-4_B3",
            bg=NAVY_DARK, fg=WHITE, font=("Arial", 8, "bold")
        ).pack(side="right", padx=22)

    def _select_first_event(self):
        first = self.service.event_names()[0]
        self.select_event(first)

    def select_event(self, event_name):
        self.event_var.set(event_name)
        self._event_changed()

    def _event_changed(self, _event=None):
        event = self.service.get_event_info(self.event_var.get())

        if event is None:
            self.event_date_var.set("Select an event")
            self.venue_var.set("Select an event")
            self.type_var.set("")
            self.type_combo["values"] = ()
            return

        self.event_date_var.set(event["date"])
        self.venue_var.set(event["venue"])

        valid_types = event["ticket_types"]
        self.type_combo["values"] = valid_types

        # Keep the selection valid whenever the event changes.
        if self.type_var.get() not in valid_types:
            self.type_var.set(valid_types[0])

    def add_ticket(self):
        success, errors, queue_number = self.service.add_ticket(
            self.name_var.get(),
            self.contact_var.get(),
            self.event_var.get(),
            self.type_var.get(),
            self.quantity_var.get()
        )

        if not success:
            messagebox.showerror(
                "Cannot Add Request",
                "\n".join(f"• {error}" for error in errors)
            )
            return

        messagebox.showinfo(
            "Request Added",
            f"Ticket request added successfully.\n\n"
            f"Queue Number: #{queue_number}\n"
            f"Event: {self.event_var.get()}\n"
            f"Ticket Type: {self.type_var.get()}\n"
            f"Quantity: {self.quantity_var.get()}"
        )

        self.clear_form()
        self.refresh_table()

    def process_next(self):
        record = self.service.process_next()

        if record is None:
            messagebox.showinfo(
                "Queue Empty",
                "There are no Waiting ticket requests to process."
            )
            self.refresh_table()
            return

        messagebox.showinfo(
            "FIFO Processing Complete",
            f"Queue #{record['queue_number']} has been served.\n\n"
            f"Customer: {record['customer_name']}\n"
            f"Event: {record['event_name']}\n"
            f"Ticket Type: {record['ticket_type']}\n"
            f"Quantity: {record['quantity']}"
        )
        self.refresh_table()

    def search_records(self):
        rows = self.service.search(
            self.search_var.get(),
            self.status_var.get()
        )
        self.populate_table(rows)

    def refresh_table(self):
        rows = self.service.search("", "All")
        self.populate_table(rows)

        count = self.service.waiting_count()
        self.queue_status_var.set(f"WAITING: {count}")
        self.hero_queue.config(text=f"WAITING REQUESTS: {count}")

    def populate_table(self, rows):
        for item in self.tree.get_children():
            self.tree.delete(item)

        for row in rows:
            self.tree.insert("", "end", values=(
                row["queue_number"],
                row["customer_name"],
                row["event_name"],
                row["event_date"],
                row["ticket_type"],
                row["quantity"],
                row["status"],
                row["created_at"],
            ))

    def clear_search(self):
        self.search_var.set("")
        self.status_var.set("All")
        self.refresh_table()

    def clear_form(self):
        self.name_var.set("")
        self.contact_var.set("")
        self.quantity_var.set("1")
        self._event_changed()


if __name__ == "__main__":
    app = ConcertTicketApp()
    app.mainloop()
